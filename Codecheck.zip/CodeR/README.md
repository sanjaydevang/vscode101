 # works as usual checking the length
\n## CS50 Python Notes\nThis repository contains work notes from Harvard's CS50 Python program.
